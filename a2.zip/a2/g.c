#include <stdint.h>
void gp(uint64_t x,uint32_t y){
    int rax = x;
    int a = 0;
    int b = 1;
    int c = 3;
    if (1 > x){
       return;
    }else{
        x *= x;
        if( 3 < x){
            // goto .L9
        }else{
            return;
        }
    }






}
